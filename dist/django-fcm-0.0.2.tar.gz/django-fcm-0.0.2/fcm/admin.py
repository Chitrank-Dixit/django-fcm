from django.contrib import admin

# Register your models here.
from fcm.models import Device

admin.site.register(Device)